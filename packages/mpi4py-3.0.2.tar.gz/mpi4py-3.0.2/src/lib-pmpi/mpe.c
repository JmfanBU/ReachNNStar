char pympi_pmpi_name[] = "mpe";
