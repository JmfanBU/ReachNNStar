from mpi4py import rc
from mpi4py import MPI
